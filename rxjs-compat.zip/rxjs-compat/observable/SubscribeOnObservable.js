"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.SubscribeOnObservable = internal_compatibility_1.SubscribeOnObservable;
//# sourceMappingURL=SubscribeOnObservable.js.map