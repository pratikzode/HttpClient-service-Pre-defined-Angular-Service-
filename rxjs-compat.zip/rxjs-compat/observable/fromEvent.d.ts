export { fromEvent } from 'rxjs';
