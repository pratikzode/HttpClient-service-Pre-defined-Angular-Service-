export { pairs } from 'rxjs';
