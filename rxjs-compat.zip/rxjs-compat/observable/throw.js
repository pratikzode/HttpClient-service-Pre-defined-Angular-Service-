"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports._throw = rxjs_1.throwError;
//# sourceMappingURL=throw.js.map