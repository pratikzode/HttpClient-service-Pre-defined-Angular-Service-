"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.fromArray = rxjs_1.from;
//# sourceMappingURL=fromArray.js.map