export { interval } from 'rxjs';
