export { from as fromPromise } from 'rxjs';
