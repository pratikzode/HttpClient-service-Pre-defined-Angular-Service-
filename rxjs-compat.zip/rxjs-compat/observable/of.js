"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.of = rxjs_1.of;
//# sourceMappingURL=of.js.map