"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.bindCallback = rxjs_1.bindCallback;
//# sourceMappingURL=bindCallback.js.map