"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.webSocket = internal_compatibility_1.webSocket;
//# sourceMappingURL=webSocket.js.map