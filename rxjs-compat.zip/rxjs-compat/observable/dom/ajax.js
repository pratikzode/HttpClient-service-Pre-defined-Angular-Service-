"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.ajax = internal_compatibility_1.ajax;
//# sourceMappingURL=ajax.js.map