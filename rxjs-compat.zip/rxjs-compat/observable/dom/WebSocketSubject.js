"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.WebSocketSubject = internal_compatibility_1.WebSocketSubject;
//# sourceMappingURL=WebSocketSubject.js.map