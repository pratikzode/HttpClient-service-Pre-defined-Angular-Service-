export { webSocket } from 'rxjs/internal-compatibility';
