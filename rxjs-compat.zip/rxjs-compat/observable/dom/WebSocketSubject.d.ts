export { WebSocketSubjectConfig, WebSocketSubject } from 'rxjs/internal-compatibility';
