"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.ajaxGet = internal_compatibility_1.ajaxGet;
exports.ajaxPost = internal_compatibility_1.ajaxPost;
exports.ajaxDelete = internal_compatibility_1.ajaxDelete;
exports.ajaxPut = internal_compatibility_1.ajaxPut;
exports.ajaxPatch = internal_compatibility_1.ajaxPatch;
exports.ajaxGetJSON = internal_compatibility_1.ajaxGetJSON;
exports.AjaxObservable = internal_compatibility_1.AjaxObservable;
exports.AjaxSubscriber = internal_compatibility_1.AjaxSubscriber;
exports.AjaxResponse = internal_compatibility_1.AjaxResponse;
exports.AjaxError = internal_compatibility_1.AjaxError;
exports.AjaxTimeoutError = internal_compatibility_1.AjaxTimeoutError;
//# sourceMappingURL=AjaxObservable.js.map