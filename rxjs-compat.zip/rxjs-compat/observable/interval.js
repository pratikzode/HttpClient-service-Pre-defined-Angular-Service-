"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.interval = rxjs_1.interval;
//# sourceMappingURL=interval.js.map