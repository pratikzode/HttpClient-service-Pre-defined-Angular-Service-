"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.fromIterable = internal_compatibility_1.fromIterable;
//# sourceMappingURL=fromIterable.js.map