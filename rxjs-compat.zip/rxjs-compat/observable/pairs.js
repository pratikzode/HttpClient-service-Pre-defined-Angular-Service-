"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.pairs = rxjs_1.pairs;
//# sourceMappingURL=pairs.js.map