"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.zip = rxjs_1.zip;
//# sourceMappingURL=zip.js.map