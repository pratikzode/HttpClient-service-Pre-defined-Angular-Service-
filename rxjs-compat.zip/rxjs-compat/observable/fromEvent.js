"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.fromEvent = rxjs_1.fromEvent;
//# sourceMappingURL=fromEvent.js.map