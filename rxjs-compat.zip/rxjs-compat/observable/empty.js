"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.empty = rxjs_1.empty;
//# sourceMappingURL=empty.js.map