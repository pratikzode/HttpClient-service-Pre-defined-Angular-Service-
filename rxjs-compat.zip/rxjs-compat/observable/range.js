"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.range = rxjs_1.range;
var internal_compatibility_1 = require("rxjs/internal-compatibility");
exports.dispatch = internal_compatibility_1.dispatch;
//# sourceMappingURL=range.js.map