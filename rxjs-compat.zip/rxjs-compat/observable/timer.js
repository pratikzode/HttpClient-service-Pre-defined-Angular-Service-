"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.timer = rxjs_1.timer;
//# sourceMappingURL=timer.js.map