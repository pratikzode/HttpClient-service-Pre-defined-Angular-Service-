"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.forkJoin = rxjs_1.forkJoin;
//# sourceMappingURL=forkJoin.js.map