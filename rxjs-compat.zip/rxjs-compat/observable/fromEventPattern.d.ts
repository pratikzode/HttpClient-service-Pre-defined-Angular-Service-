export { fromEventPattern } from 'rxjs';
