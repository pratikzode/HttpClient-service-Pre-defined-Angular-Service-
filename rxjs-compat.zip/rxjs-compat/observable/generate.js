"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.generate = rxjs_1.generate;
//# sourceMappingURL=generate.js.map