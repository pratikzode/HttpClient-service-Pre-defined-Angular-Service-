"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var delay_1 = require("../../operator/delay");
rxjs_1.Observable.prototype.delay = delay_1.delay;
//# sourceMappingURL=delay.js.map