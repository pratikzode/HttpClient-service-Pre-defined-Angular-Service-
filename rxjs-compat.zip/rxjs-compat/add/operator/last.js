"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var last_1 = require("../../operator/last");
rxjs_1.Observable.prototype.last = last_1.last;
//# sourceMappingURL=last.js.map