"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var audit_1 = require("../../operator/audit");
rxjs_1.Observable.prototype.audit = audit_1.audit;
//# sourceMappingURL=audit.js.map