"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var every_1 = require("../../operator/every");
rxjs_1.Observable.prototype.every = every_1.every;
//# sourceMappingURL=every.js.map