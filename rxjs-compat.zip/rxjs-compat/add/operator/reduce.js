"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var reduce_1 = require("../../operator/reduce");
rxjs_1.Observable.prototype.reduce = reduce_1.reduce;
//# sourceMappingURL=reduce.js.map