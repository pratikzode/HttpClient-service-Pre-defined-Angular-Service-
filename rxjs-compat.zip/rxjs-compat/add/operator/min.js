"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var min_1 = require("../../operator/min");
rxjs_1.Observable.prototype.min = min_1.min;
//# sourceMappingURL=min.js.map