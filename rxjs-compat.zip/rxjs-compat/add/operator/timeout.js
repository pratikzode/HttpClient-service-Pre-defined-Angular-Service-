"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var timeout_1 = require("../../operator/timeout");
rxjs_1.Observable.prototype.timeout = timeout_1.timeout;
//# sourceMappingURL=timeout.js.map