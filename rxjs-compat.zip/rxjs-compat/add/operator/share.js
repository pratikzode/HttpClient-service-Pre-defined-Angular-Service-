"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var share_1 = require("../../operator/share");
rxjs_1.Observable.prototype.share = share_1.share;
//# sourceMappingURL=share.js.map