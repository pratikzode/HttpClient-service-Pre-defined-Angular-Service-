"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var scan_1 = require("../../operator/scan");
rxjs_1.Observable.prototype.scan = scan_1.scan;
//# sourceMappingURL=scan.js.map