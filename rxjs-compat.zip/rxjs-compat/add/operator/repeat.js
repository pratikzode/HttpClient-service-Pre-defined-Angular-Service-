"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var repeat_1 = require("../../operator/repeat");
rxjs_1.Observable.prototype.repeat = repeat_1.repeat;
//# sourceMappingURL=repeat.js.map