"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var publish_1 = require("../../operator/publish");
rxjs_1.Observable.prototype.publish = publish_1.publish;
//# sourceMappingURL=publish.js.map