"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var pluck_1 = require("../../operator/pluck");
rxjs_1.Observable.prototype.pluck = pluck_1.pluck;
//# sourceMappingURL=pluck.js.map