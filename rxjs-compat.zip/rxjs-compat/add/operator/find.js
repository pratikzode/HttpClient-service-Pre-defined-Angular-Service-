"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var find_1 = require("../../operator/find");
rxjs_1.Observable.prototype.find = find_1.find;
//# sourceMappingURL=find.js.map