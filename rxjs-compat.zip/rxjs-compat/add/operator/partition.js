"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var partition_1 = require("../../operator/partition");
rxjs_1.Observable.prototype.partition = partition_1.partition;
//# sourceMappingURL=partition.js.map