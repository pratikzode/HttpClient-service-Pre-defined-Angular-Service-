"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var startWith_1 = require("../../operator/startWith");
rxjs_1.Observable.prototype.startWith = startWith_1.startWith;
//# sourceMappingURL=startWith.js.map