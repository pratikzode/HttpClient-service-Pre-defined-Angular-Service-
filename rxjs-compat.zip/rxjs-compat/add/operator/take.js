"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var take_1 = require("../../operator/take");
rxjs_1.Observable.prototype.take = take_1.take;
//# sourceMappingURL=take.js.map