"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var merge_1 = require("../../operator/merge");
rxjs_1.Observable.prototype.merge = merge_1.merge;
//# sourceMappingURL=merge.js.map