"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var single_1 = require("../../operator/single");
rxjs_1.Observable.prototype.single = single_1.single;
//# sourceMappingURL=single.js.map