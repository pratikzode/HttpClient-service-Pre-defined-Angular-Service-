"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var expand_1 = require("../../operator/expand");
rxjs_1.Observable.prototype.expand = expand_1.expand;
//# sourceMappingURL=expand.js.map