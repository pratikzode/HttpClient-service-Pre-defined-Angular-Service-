"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var race_1 = require("../../operator/race");
rxjs_1.Observable.prototype.race = race_1.race;
//# sourceMappingURL=race.js.map