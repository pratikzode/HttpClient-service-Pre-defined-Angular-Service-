"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.defer = rxjs_1.defer;
//# sourceMappingURL=defer.js.map