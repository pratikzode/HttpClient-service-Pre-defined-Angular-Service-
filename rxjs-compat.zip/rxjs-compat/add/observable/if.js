"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.if = rxjs_1.iif;
//# sourceMappingURL=if.js.map