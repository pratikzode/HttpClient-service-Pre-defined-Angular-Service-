"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.range = rxjs_1.range;
//# sourceMappingURL=range.js.map