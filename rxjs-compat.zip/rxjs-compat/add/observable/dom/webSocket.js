"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
var webSocket_1 = require("rxjs/webSocket");
rxjs_1.Observable.webSocket = webSocket_1.webSocket;
//# sourceMappingURL=webSocket.js.map