"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.merge = rxjs_1.merge;
//# sourceMappingURL=merge.js.map