"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.bindNodeCallback = rxjs_1.bindNodeCallback;
//# sourceMappingURL=bindNodeCallback.js.map