"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
rxjs_1.Observable.fromPromise = rxjs_1.from;
//# sourceMappingURL=fromPromise.js.map