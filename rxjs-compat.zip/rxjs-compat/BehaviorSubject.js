"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var rxjs_1 = require("rxjs");
exports.BehaviorSubject = rxjs_1.BehaviorSubject;
//# sourceMappingURL=BehaviorSubject.js.map